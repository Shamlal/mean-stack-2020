var express = require('express');
var mysql=require("mysql");
var router = express.Router();



/*
drop database bank;
create database bank;
use  bank;
create table accounts(accno int primary key,name text,balance float,doc date);
insert into accounts values(101,'Pradeep Chinchole',10000.55,'2011-11-11');
insert into accounts values(102,'Satadru Roy',20000.55,'2012-11-11');
insert into accounts values(103,'Pratik Chougule',30000.55,'2013-11-11');
insert into accounts values(104,'Nikhil Wagare',40000.55,'2014-11-11');
insert into accounts values(105,'Viday Gahire Wagare',50000.55,'2015-11-11');
*/


var connection=mysql.createConnection({
    host:"localhost",
    database:'bank',
    user:'root',
    password:'admin',
    port:3306
},function(){
   console.log("Connection established with MySQL");     
});





/* GET all accounts */
router.get('/accounts', function(req, res, next) {

connection.query("SELECT * FROM ACCOUNTS",function(err,data){
if(err) res.send(""+err);

res.json(data);

});

});



/* GET account by accno */
router.get('/accounts/:accno', function(req, res, next) {
    
    var accno=parseInt(req.params.accno);
       
    connection.query("SELECT * FROM ACCOUNTS WHERE ACCNO=?",[accno],function(err,data){
        if(err) res.send(""+err);
        
        res.json(data[0]);
        
        });
    

});
  

/* DELETE account by accno */
router.delete('/accounts/:accno', function(req, res, next) {
    
    var accno=parseInt(req.params.accno);

  
connection.query("DELETE FROM ACCOUNTS WHERE ACCNO=?",[accno],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM ACCOUNTS",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
   
    });

 });



});
  


/* UPDATE account by accno */
router.put('/accounts/:accno', function(req, res, next) {
    
    var accno=parseInt(req.params.accno);

    var account=req.body;


    connection.query("UPDATE ACCOUNTS SET NAME=?,BALANCE=?,DOC=? WHERE ACCNO=?",[account.name,account.balance,account.doc,accno],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM ACCOUNTS",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
   
    });

 });






    
});
  

/* ADD account */
router.post('/accounts', function(req, res, next) {
    
     var account=req.body;

   
 connection.query("INSERT INTO ACCOUNTS SET ?",[account],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM ACCOUNTS",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
    });

 });
/*
or
    
 connection.query("INSERT INTO ACCOUNTS VALUES(?,?,?,?)",[account.accno,account.name,account.balance,account.doc],function(err,data){
        if(err) res.send(""+err);

        
  connection.query("SELECT * FROM ACCOUNTS",function(err,data){
    if(err) res.send(""+err);
    
    res.json(data);
    });

 });


*/

    
});
  

module.exports = router;
