var express = require('express');
var router = express.Router();
var mongoose = require("mongoose");

var dbName = 'accounts';
var connectionString = 'mongodb://localhost:27017/' + dbName;

//create a connection with mmongodb

mongoose.connect(connectionString);

var Schema = mongoose.Schema;

var accountSchema = new Schema({
    accountId: Number,
    name: String,
    balance: Number,
    dob: Date,
});

var Account = mongoose.model('account', accountSchema);

/* GET all accounts  */
router.get('/accounts', function (req, res, next) {

    Account.find(function (err, accounts) {
        if (err)
            return res.send(err);
        res.json(accounts);
    })

});


/* GET user by userId  */
router.get('/accounts/:accountId', function (req, res, next) {
    var account_Id = req.params.accountId;

    Account.findOne({
        accountId: account_id
    }, function (err, account) {
        if (err)
            return res.send(err);
        res.json(account);
    })
});

/* DELETE account by accountId  */
router.delete('/accounts/:accountId', function (req, res, next) {
    var account_id = req.params.accountId;

    Account.remove({
        accountId: account_id
    }, function (err, account) {
        if (err)
            return res.send(err);

        Account.find(function (err, accounts) {
            if (err)
                return res.send(err);
            res.json(accounts);
        });
    })
});

/* UPDATE account by accountId  */
router.put('/accounts/:accountId', function (req, res, next) {
    var account_id = req.params.accountId;


    Account.findOne({
        accountId: account_id
    }, function (error, account) {
        if (error)
            return res.send(error);

        for (prop in req.body) {
            account[prop] = req.body[prop];
        }
        account.save(function (err, result) {
            Account.find(function (err, accounts) {
                if (err)
                    return res.send(err);
                res.json(accounts);
            });
        });
    });
});



    /* ADD account */
    router.post('/accounts', function (req, res, next) {
        var account = new Account(req.body);

        account.save(function (err) {
            if (err)
                return res.send(err);

            Account.find(function (err, accounts) {
                if (err)
                    return res.send(err);
                res.json(accounts);
            });
        });

    });

module.exports = router;