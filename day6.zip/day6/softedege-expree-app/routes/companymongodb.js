var express = require('express');
var router = express.Router();
var mongoose=require("mongoose");

var dbName = 'company';
var connectionString = 'mongodb://localhost:27017/' + dbName;

//create a connection with mmongodb

mongoose.connect(connectionString);

var Schema=mongoose.Schema;

var userSchema = new Schema({
  userId: Number,
  name: String,
  address: String,
  email: String,
});

var  User=mongoose.model('user', userSchema);

/* GET all users  */
router.get('/users', function(req, res, next) {

    User.find(function(err,users){
        if(err)
        return res.send(err);
        res.json(users);
       })
});

/* GET user by userId  */
router.get('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;

  User.findOne({userId:user_id},function(err,user){
    if(err)
    return res.send(err);
    res.json(user);
   })
});



/* DELETE user by userId  */
router.delete('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;

  User.remove({userId:user_id},function(err,user){
    if(err)
    return res.send(err);
  
    User.find(function(err,users){
      if(err)
      return res.send(err);
      res.json(users);
     });
  })

});









/* UPDATE user by userId  */
router.put('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;
  

  User.findOne({userId:user_id},function (error,user){
    if(error)
    return res.send(error);
    
    for (prop in req.body) {
        user[prop] = req.body[prop];
      }
    user.save(function(err,result){
        User.find(function(err,users){
            if(err)
            return res.send(err);
            res.json(users);
           });
    });
   
  }); 

});





/* ADD user */
router.post('/users', function(req, res, next) {
    var user=new User(req.body);

user.save(function(err){
  if(err)
  return res.send(err);

  User.find(function(err,users){
    if(err)
    return res.send(err);
    res.json(users);
   });
});
  
});


module.exports = router;
