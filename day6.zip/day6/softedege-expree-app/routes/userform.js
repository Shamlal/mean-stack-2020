var express = require('express');
var router = express.Router();
var mongoose = require("mongoose");


var dbName = 'UserDB';
var connectionString = 'mongodb://localhost:27017/' + dbName;
mongoose.connect(connectionString);
var Schema = mongoose.Schema;
var userSchema = new Schema({
    userId: Number,
    name: String,
    address: String,
    email: String,
});

var User = mongoose.model('users', userSchema);

router.post('/', function (req, res, next) {
    var name = req.body.name;
    var userId = req.body.userId;
    var email = req.body.email;
    var address = req.body.address;

    var action = req.body.action;

    if (action == "Add") {
        /* ADD user */
        var user = new User({
            userId: userId,
            name: name,
            email: email,
            address: address
        });

        console.log('user data:' + user);

        user.save(function (err) {
            if (err)
                return res.send(err);

            User.find(function (err, users) {
                if (err)
                    return res.send(err);

                res.json(users);
            });
        });

    } else if (action == "Remove") {
        /* DELETE user by userId  */
        User.remove({
            userId: userId
        }, function (err, user) {
            if (err)
                return res.send(err);

            User.find(function (err, users) {
                if (err)
                    return res.send(err);
                res.json(users);
            });

        })

    } else if (action == "Update") {
        /* UPDATE user by userId  */
        var user_id = userId;

        User.findOne({
            userId: user_id
        }, function (error, user) {
            if (error)
                return res.send(error);

            for (prop in req.body) {
                user[prop] = req.body[prop];
            }
            user.save(function (err, result) {

                User.find(function (err, users) {
                    if (err)
                        return res.send(err);
                    res.json(users);
                });

            });
        });
    }

    res.send("Result :" + action);
});

module.exports = router;