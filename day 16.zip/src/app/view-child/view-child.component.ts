import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NumberComponent } from '../number/number.component';
import { FgColorDirective } from '../directives/fg-color.directive';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {

  @ViewChild(NumberComponent, {static: false}) 
  private nc: NumberComponent; 

  @ViewChild(FgColorDirective, {static: false}) 
  private f: FgColorDirective; 

  @ViewChild("name", {static: false}) 
  name: ElementRef<any>; 

  @ViewChild("city", {static: false}) 
  city: ElementRef<any>; 


  constructor() { }

  ngOnInit(): void {
  }

  increase() 
  { 
    this.nc.increment(); 
  } 

  decrease() 
  { 
    this.nc.decrement(); 
  } 


  changeColor() 
  { 
    this.f.fgColor = "magenta"; 
  } 

  changeColors() 
  { 
    this.name.nativeElement.style.color = "RED"; 
    this.city.nativeElement.style.color = "GREEN"; 
          
    this.name.nativeElement.style.backgroundColor = "CYAN"; 
    this.city.nativeElement.style.backgroundColor = "YELLOW"; 
  } 

} 
