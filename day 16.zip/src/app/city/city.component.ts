import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit 
{ 

  message = "Hello from City. "; 
  
  @Input() 
  stateMessage = ""; 

  @Input() 
  countryMessage = ""; 

  @Output() 
  cityChanged = new EventEmitter<string>(); 


  sendMessageToState() 
  { 
    console.log("Sent message to State. " + this.message); 
    this.cityChanged.emit(this.message); 
  } 


  constructor() {
    console.log("=========== CityComponent created ===========");
   }
  
  ngOnInit(): void {
    console.log("=========== CityComponent initialised ===========");
  }
  
  ngOnDestroy(): void {
    console.log("=========== CityComponent destroyed ==========="); 
  }
  
  ngOnChanges(): void {
    console.log("=========== CityComponent ngOnChanges ==========="); 
  } 
  
  ngDoCheck(): void {
    console.log("=========== CityComponent ngDoCheck ==========="); 
  } 
  
  ngAfterContentInit(): void {
    console.log("=========== CityComponent ngAfterContentInit ==========="); 
  } 
  
  ngAfterContentChecked(): void {
    console.log("=========== CityComponent ngAfterContentChecked ==========="); 
  } 
  
  ngAfterViewInit(): void {
    console.log("=========== CityComponent ngAfterViewInit ==========="); 
  } 
  
  ngAfterViewChecked(): void {
    console.log("=========== CityComponent ngAfterViewChecked ==========="); 
  } 

} 
