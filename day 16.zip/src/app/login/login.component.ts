import { Component, OnInit } from '@angular/core'; 
import { FormGroup, FormBuilder, Validators } from '@angular/forms'; 
import { Router } from '@angular/router'; 

@Component({ 
  selector: 'app-login', 
  templateUrl: './login.component.html', 
  styleUrls: ['./login.component.css'] 
}) 
export class LoginComponent implements OnInit { 

  title = "Login Form"; 

  loginForm: FormGroup; 

  constructor(private fb:FormBuilder,private router:Router) 
  { 
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent created   $$$$$$$$$$"); 
  } 

  ngOnInit(): void 
  { 
    this.loginForm = this.fb.group({ 
              //email: ["ram@gmail.com",Validators.required], 
              email: ["ram@gmail.com",Validators.compose([Validators.required, Validators.email])], 
              password: ["ram@1234",Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(10)])] 
                                  }); 
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent initialized   $$$$$$$$$$"); 
  } 

  get lf() 
  { 
    return this.loginForm; 
  } 

  submitForm(loginValue) 
  { 
    sessionStorage.setItem("email", loginValue.email); 
    alert(JSON.stringify(loginValue)); 
    this.router.navigate(['/home']); 
  } 

} 
