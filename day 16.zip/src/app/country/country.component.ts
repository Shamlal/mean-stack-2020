import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  message = "Hello from Country. "; 

  stateMessage = ""; 

  cityMessage = ""; 
  
  
  constructor() {
    console.log("=========== CountryComponent created ===========");
   }
  
  ngOnInit(): void {
    console.log("=========== CountryComponent initialised ===========");
  }
  
  ngOnDestroy(): void {
    console.log("=========== CountryComponent destroyed ==========="); 
  }
  
  ngOnChanges(): void {
    console.log("=========== CountryComponent ngOnChanges ==========="); 
  } 
  
  ngDoCheck(): void {
    console.log("=========== CountryComponent ngDoCheck ==========="); 
  } 
  
  ngAfterContentInit(): void {
    console.log("=========== CountryComponent ngAfterContentInit ==========="); 
  } 
  
  ngAfterContentChecked(): void {
    console.log("=========== CountryComponent ngAfterContentChecked ==========="); 
  } 
  
  ngAfterViewInit(): void {
    console.log("=========== CountryComponent ngAfterViewInit ==========="); 
  } 
  
  ngAfterViewChecked(): void {
    console.log("=========== CountryComponent ngAfterViewChecked ==========="); 
  } 

}
