import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested',
  templateUrl: './nested.component.html',
  styleUrls: ['./nested.component.css']
})
export class NestedComponent implements OnInit {

  constructor() {
    console.log("=========== NestedComponent created ===========");
   }
  
  ngOnInit(): void {
    console.log("=========== NestedComponent initialised ===========");
  }
  
  ngOnDestroy(): void {
    console.log("=========== NestedComponent destroyed ==========="); 
  }
  
  ngOnChanges(): void {
    console.log("=========== NestedComponent ngOnChanges ==========="); 
  } 
  
  ngDoCheck(): void {
    console.log("=========== NestedComponent ngDoCheck ==========="); 
  } 
  
  ngAfterContentInit(): void {
    console.log("=========== NestedComponent ngAfterContentInit ==========="); 
  } 
  
  ngAfterContentChecked(): void {
    console.log("=========== NestedComponent ngAfterContentChecked ==========="); 
  } 
  
  ngAfterViewInit(): void {
    console.log("=========== NestedComponent ngAfterViewInit ==========="); 
  } 
  
  ngAfterViewChecked(): void {
    console.log("=========== NestedComponent ngAfterViewChecked ==========="); 
  } 

}
