import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[ngHide]'
})
export class NgHideDirective {

  constructor(private t: TemplateRef<any>, private vcr: ViewContainerRef) {
    console.log(" NgHide Dirctive is created. "); 
   }

   @Input()
   set ngHide(value: boolean)
   {
    console.log(" Inside setNgHide method :  " + value)
    
    if(!value) 
      this.vcr.createEmbeddedView(this.t); 
    else 
      this.vcr.clear(); 
   }

}
