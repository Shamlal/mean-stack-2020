import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExpressService 
{ 

  private baseURL = "http://localhost:8081/companymysql/users"; 

  constructor(private http: HttpClient) 
  { 
    console.log("==== ExpressService Created ====="); 
  }


  getAllUsers(): Observable<any> 
  { 
     return this.http.get(this.baseURL); 
  } 

  getUserById(userId: number): Observable<any> 
  { 
     return this.http.get(this.baseURL + "/" + userId); 
  } 

  deleteUserById(userId: number): Observable<any> 
  { 
     return this.http.delete(this.baseURL + "/" + userId); 
  }

  updateUserById(userId: number, user: any): Observable<any> 
  { 
     return this.http.put(this.baseURL + "/" + userId, user); 
  }

  addUser(user: any): Observable<any> 
  { 
     return this.http.post(this.baseURL, user); 
  } 
}
