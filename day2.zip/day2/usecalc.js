var c=require("./calc.js");
console.log(c.message);

console.log("100 + 20 :"+c.add(100,20));
console.log("100 - 20 :"+c.sub(100,20));
console.log("100 * 20 :"+c.mul(100,20));
console.log("100 / 20 :"+c.div(100,20));
console.log("100 % 20 :"+c.mod(100,20));
