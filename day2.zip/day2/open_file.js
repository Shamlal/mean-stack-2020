var fs = require("fs");
// Asynchronous - Opening File
console.log("Going to open file!");

fs.open('calc.js', 'r', function(err, data) {
if (err) {
return console.error(err);
}
console.log(data);
console.log("File opened successfully over");
});