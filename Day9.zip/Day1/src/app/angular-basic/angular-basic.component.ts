import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-basic',
  templateUrl: './angular-basic.component.html',
  styleUrls: ['./angular-basic.component.css']
})
export class AngularBasicComponent implements OnInit {

  constructor() {
    console.log("-- AngularBasicComponent created --");
   }

  ngOnInit(): void {
    console.log("-- AngularBasicComponent intiated --");
  }

  ngOnDestroy(): void {
    console.log("-- AngularBasicComponent destroyed --");
  }

}
