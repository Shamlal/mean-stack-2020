import { Component, OnInit } from '@angular/core';
import { TodosService } from '../services/todos.service';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  title = "Todos Table"; 
  todos: any; 
  message = ""; 
  
  constructor(private ts: TodosService) 
  { 
    console.log("===== TodosComponent created ======"); 
  } 

  ngOnInit(): void 
  { 
    this.getAllTodos(); 
    console.log("===== TodosComponent initialized ======"); 
  } 

  ngOnDestroy(): void 
  { 
    console.log("===== TodosComponent destroyed ======"); 
  } 

   getAllTodos() 
   {
     this.ts.getAllTodos() 
        .subscribe(response => this.todos = response, 
                    error => this.message = error); 
   }

}
