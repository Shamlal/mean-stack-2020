import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../services/albums.service';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit 
{ 

  title = "Albums Table"; 
  albums: any; 
  message = ""; 
  
  constructor(private as: AlbumsService) 
  { 
    console.log("===== AlbumsComponent created ======"); 
  } 

  ngOnInit(): void 
  { 
    this.getAllAlbums(); 
    console.log("===== AlbumsComponent initialized ======"); 
  } 

  ngOnDestroy(): void 
  { 
    console.log("===== AlbumsComponent destroyed ======"); 
  } 

   getAllAlbums() 
   { 
     this.as.getAllAlbums() 
        .subscribe(response => this.albums = response, 
                    error => this.message = error); 
   } 

} 
