import { Component, OnInit } from '@angular/core';
import { PhotosService } from '../services/photos.service';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit 
{ 

  title = "Photos Table"; 
  photos: any; 
  message = ""; 
  
  constructor(private phs: PhotosService) 
  { 
    console.log("===== PhotosComponent created ======"); 
  } 

  ngOnInit(): void 
  { 
    this.getAllPhotos(); 
    console.log("===== PhotosComponent initialized ======"); 
  } 

  ngOnDestroy(): void 
  { 
    console.log("===== PhotosComponent destroyed ======"); 
  } 

   getAllPhotos() 
   { 
     this.phs.getAllPhotos() 
        .subscribe(response => this.photos = response, 
                    error => this.message = error); 
   } 

}
