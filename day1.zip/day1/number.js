var a=new Number(100);
var b=new Number(100.456788);

var c="100";
var e=new String("111");
var d=34.56;

console.log("a    = "+a);
console.log("b    = "+b);
console.log("b    = "+b.toString());
console.log("Max  = "+Number.MAX_VALUE);
console.log("Min  = "+Number.MIN_VALUE);
console.log(typeof(a));
console.log(typeof(b));
console.log(typeof(c));
console.log(typeof(d));
console.log(typeof(e));
console.log(a==c); 
console.log(a===c);
console.log(a.toString()==c);
console.log(a.toString()===c);




