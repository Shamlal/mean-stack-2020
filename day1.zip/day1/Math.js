
console.log("Sqrt(4)      :"+Math.sqrt(4));
console.log("pow(10,2)    :"+Math.pow(10,2));
console.log("ceil(10.5)   :"+Math.ceil(10.5));
console.log("floor(10.5)  :"+Math.floor(10.5));
console.log("round(10.45) :"+Math.round(10.45));
console.log("round(10.51) :"+Math.round(10.51));
console.log("sine(0)      :"+Math.sin(0));
console.log("cos(0)       :"+Math.cos(0));
console.log("abs(-100)    :"+Math.abs(-100));
console.log("PI           :"+Math.PI);
console.log("max(100,300,400)      :"+Math.max(100,300,400));
console.log("min(100,300,400)      :"+Math.min(100,300,400));
console.log("Random      :"+Math.random());
