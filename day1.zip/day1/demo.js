10+10
10<10
a=100;
b=200;
a+b;
i=0;while(i<=10){console.log(i);i++}
