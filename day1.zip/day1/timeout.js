//var ts=require("timers");

function welcome(){
    console.log("Welcome To Timer Module");
}


var timer=setInterval(welcome,1000);
 
setTimeout(release,6000);

function release(){
    clearInterval(timer);
}












