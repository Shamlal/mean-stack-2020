
var express = require('express');
var expressFileUpload = require('express-fileupload');
var expressSession=require("express-session");
var cookieParser = require('cookie-parser');
var indexRouter = require('./routes/index');
var companyArray = require('./routes/companyarray');
var companymysql = require('./routes/companymysql');
var companymongodb = require('./routes/companymongodb');
var login = require('./routes/login');
var calculate = require('./routes/calculate');
var upload = require('./routes/upload');
var shopping = require('./routes/shopping');

var cookiedemo = require('./routes/cookiedemo');





var app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));
app.use(cookieParser());

app.use(expressFileUpload());//enable file uplading

app.use(expressSession({
    resave:true,
    saveUninitialized:true,
    secret:"Hello"
}));



app.use('/', indexRouter);
app.use('/companyarray', companyArray);
app.use('/companymysql', companymysql);
app.use('/companymongodb', companymongodb);
app.use('/login', login);
app.use('/upload', upload);
app.use('/calculate', calculate);
app.use('/cookiedemo', cookiedemo);
app.use('/shopping', shopping);







module.exports = app;
