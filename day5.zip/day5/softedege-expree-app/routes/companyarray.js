var express = require('express');
var router = express.Router();


users=[
  {userId:101,name:'Ram Patil',email:'Ram@gmail.com',
    dob:new Date("July 21,1999")},
  {userId:102,name:'Sachin Patil',email:'Ram@gmail.com',
  dob:new Date("July 20,1972")},
  {userId:103,name:'Mohan Patil',email:'Ram@gmail.com',
  dob:new Date("July 11,1988")}
  ];






/* GET all users  */
router.get('/users', function(req, res, next) {
  res.json(users);
});


/* GET user by userId  */
router.get('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;

  var user=users.filter((user,index)=>user_id==user.userId)[0];
 
  res.json(user);

});

/* DELETE user by userId  */
router.delete('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;

  users=users.filter((user,index)=>user_id!=user.userId);
 
  res.json(users);

});


/* UPDATE user by userId  */
router.put('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;
  var u=req.body;
  
  users.forEach((user,index)=>{
    if(user.userId==user_id)
    users[index]=u;
  });
  

  res.json(users);

});



/* ADD user */
router.post('/users', function(req, res, next) {
  var u=req.body;
  users.push(u);
  res.json(users);
});


module.exports = router;
