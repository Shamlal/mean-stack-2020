var express = require('express');
var router = express.Router();
var mysql=require("mysql");

/*
use test;

create table accounts(accno int primary key,name text,balance float,doc date);
insert into accounts values(101,'Ameya',11000.455,'2011-11-11');
insert into accounts values(102,'Sunil',12000.455,'2012-11-11');
insert into accounts values(103,'Sachin',13000.455,'2013-11-11');
insert into accounts values(104,'Pradeep',14000.455,'2014-11-11');

select * from accounts;



*/



var connection=mysql.createConnection({
database:'test',
host:'localhost',
port:3306,
user:'root',
password:'admin'
},function(err){
    if(err)
    return console.error(err);
    console.log("Connection estabished with MySQL Server");
});



/* GET all accounts */
router.get('/accounts', function(req, res, next) {
    
    connection.query("SELECT * FROM ACCOUNTS",function(err,data){
        if(err)
        return console.error(err);

        res.json(data);
    })
      

});


/* GET account by accnos */
router.get('/accounts/:accno', function(req, res, next) {
    
    var acno=parseInt(req.params.accno);

    connection.query("SELECT * FROM ACCOUNTS WHERE ACCNO=?",[acno],function(err,data){
        if(err)
        return console.error(err);
        res.json(data[0]);
    })
      

});


/* DELETE account by accnos */
router.delete('/accounts/:accno', function(req, res, next) {
    
    var acno=parseInt(req.params.accno);

    connection.query("DELETE FROM ACCOUNTS WHERE ACCNO=?",[acno],function(err,data){
        if(err)
        return console.error(err);
        
    connection.query("SELECT * FROM ACCOUNTS",function(err,data){
            if(err)
            return console.error(err);
            res.json(data);
        })
           

    });
          
   
});


/* ADD account */
router.post('/accounts', function(req, res, next) {
    
    var account=req.body;

    connection.query("INSERT INTO ACCOUNTS SET ?",[account],function(err,data){
        if(err)
        return console.error(err);
        
    connection.query("SELECT * FROM ACCOUNTS",function(err,data){
            if(err)
            return console.error(err);
            res.json(data);
        })
           

    });

});

/* ADD account */
router.put('/accounts/:accno', function(req, res, next) {
    
    var acno=parseInt(req.params.accno);

    var name=req.body.name;
    var balance=req.body.balance;
    var doc=req.body.doc;
    


    connection.query("UPDATE ACCOUNTS SET NAME=?,BALANCE=?,DOC=? WHERE ACCNO=?",[name,balance,doc,acno],function(err,data){
        if(err)
        return console.error(err);
        
    connection.query("SELECT * FROM ACCOUNTS",function(err,data){
            if(err)
            return console.error(err);
            res.json(data);
        })
           

    });

});

module.exports = router;
