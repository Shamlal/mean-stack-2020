var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express Module' });
});


/* GET home page. */
router.get('/colors', function(req, res, next) {
  res.render('colors', { colors: ['RED','GREEN','BLUE','MAGENTA'] });
});

module.exports = router;
