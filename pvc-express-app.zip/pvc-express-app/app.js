var createError = require('http-errors');
var express = require('express');
var path = require('path');

var cors = require('cors');


var bankingMySQLRouter= require('./routes/bankingmysql');
var indexRouter= require('./routes/index');



var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(cors());

app.use(express.json());//enable the json data parsing
app.use(express.urlencoded({ extended: false })); //parses the data sent by form using post method

app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/bankingmysql', bankingMySQLRouter);


module.exports = app;
