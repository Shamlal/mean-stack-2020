import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit 
{ 

  message = "Hello from State. "; 
  cityMessage = ""; 

  @Input() 
  countryMessage = ""; 

  @Output() 
  stateChanged = new EventEmitter<string>(); 

  @Output() 
  cityChanged = new EventEmitter<string>(); 


  sendMessageToCountry() 
  { 
    console.log("Sent message to Country. " + this.message); 
    this.stateChanged.emit(this.message); 
    
  } 

  sendCityToCountry(cityValue) 
  { 
    console.log("Sent message to Country. " + this.message); 
    this.cityMessage = cityValue; 
    this.cityChanged.emit(this.cityMessage); 
  } 



  constructor() { }

  ngOnInit(): void {
  }

} 
