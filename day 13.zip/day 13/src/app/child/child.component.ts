import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

message="Hello Parent";

 @Input()
 parentMessage="";


@Output()
childChanged=new EventEmitter<string>();



sendMessageToParent(){
  console.log("Sent message to Parent " + this.message);  
  this.childChanged.emit(this.message);
  }
  
  constructor() { }

  ngOnInit(): void {
  }

}
