var express = require('express');
var router = express.Router();



var accounts=[
    {accno:101,name:'Pradeep Chinchole',balance:10000.00,doc:new Date()},
    {accno:102,name:'Pratik Chougule',balance:20000.00,doc:new Date()},
    {accno:103,name:'Satadru Roy',balance:30000.00,doc:new Date()},
    {accno:104,name:'Vidya Gahire',balance:40000.00,doc:new Date()},
    {accno:105,name:'Nikhil Wanare',balance:50000.00,doc:new Date()},
  
];



/* GET all accounts */
router.get('/accounts', function(req, res, next) {
  res.json(accounts);
});



/* GET account by accno */
router.get('/accounts/:accno', function(req, res, next) {
    
    var accno=parseInt(req.params.accno);

   var account=accounts.filter(function(element,index){
           return accno==element.accno;
       })[0];
       
    res.json(account);

});
  

/* DELETE account by accno */
router.delete('/accounts/:accno', function(req, res, next) {
    
    var accno=parseInt(req.params.accno);

   accounts=accounts.filter(function(element,index){
           return accno!=element.accno;
       });
       
    res.json(accounts);

});
  


/* UPDATE account by accno */
router.put('/accounts/:accno', function(req, res, next) {
    
    var accno=parseInt(req.params.accno);

    var account=req.body;

    accounts.forEach(function(element,index){
          if(element.accno==accno)
          accounts[index]=account;
   });
    res.json(accounts);

});
  

/* ADD account */
router.post('/accounts', function(req, res, next) {
    
     var account=req.body;

      accounts.push(account);

     res.json(accounts);

});
  

module.exports = router;
