import { Component, OnInit } from '@angular/core';
import { ExpressService } from '../services/express.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-express',
  templateUrl: './express.component.html',
  styleUrls: ['./express.component.css']
})
export class ExpressComponent implements OnInit {

  title = "Express User Details"; 
  users: any; 
  message = ""; 
  user: any; 

  add = false; 
  update = false; 

  
  constructor(private es: ExpressService) 
  { 
    console.log("===== ExpressComponent created ======"); 
  } 

  ngOnInit(): void 
  { 
    this.getAllUsers(); 

    console.log("===== ExpressComponent initialized ======"); 
  } 

  ngOnDestroy(): void 
  { 
    console.log("===== ExpressComponent destroyed ======"); 
  } 

  
  newUser()
  {
    this.add = false; 
    this.update = true; 
    
    this.user = 
    {
      userId: 0,
      name: "",
      email: "",
      dob: "",
    }
  }
  
  getAllUsers() 
  { 
    this.es.getAllUsers() 
      .subscribe(response => this.users = response, 
                  error => this.message = error); 
  } 

  getUserById(userId: number) 
  { 
    this.add = true; 
    this.update = false; 
    
    this.es.getUserById(userId) 
      .subscribe(response => this.user = response,  
                  error => this.message = error); 
  } 

  deleteUserById(userId: number) 
  { 
    this.es.deleteUserById(userId) 
      .subscribe(response => this.users = response,  
                  error => this.message = error); 
  } 

  updateUserById(userId: number) 
  { 
    this.es.updateUserById(userId, this.user) 
      .subscribe(response => this.users = response,  
                  error => this.message = error); 
  
    this.user = null; 
  } 

  addUser() 
  { 
    this.es.addUser(this.user) 
      .subscribe(response => this.users = response,  
                  error => this.message = error); 

    this.user = null; 
  } 

}
