import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[ngShow]'
})
export class NgShowDirective {

  constructor(private t: TemplateRef<any>, private vcr: ViewContainerRef) {
    console.log(" NgShow Dirctive is created. "); 
   }

   @Input()
   set ngShow(value: boolean)
   {
    console.log(" Inside setNgShow method :  " + value)
    
    if(value) 
      this.vcr.createEmbeddedView(this.t); 
    else 
      this.vcr.clear(); 
   }

}
