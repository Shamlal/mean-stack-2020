import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-testing',
  templateUrl: './angular-testing.component.html',
  styleUrls: ['./angular-testing.component.css']
})
export class AngularTestingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
