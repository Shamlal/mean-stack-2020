import { TestBed } from '@angular/core/testing';

import { CalculatorService } from './calculator.service';

describe('CalculatorService', () => {
  let service: CalculatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  }); 

  it('should return addition of 10 & 5 as 15', () => {
    expect(service.add(10,5)).toEqual(15); 
  }); 

  it('should return subtraction of 10 & 5 as 5', () => {
    expect(service.sub(10,5)).toEqual(5); 
  }); 
});
