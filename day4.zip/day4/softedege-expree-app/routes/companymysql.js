var express = require('express');
var router = express.Router();
var mysql=require("mysql");

/*
drop database company;

create database company;

use company;

create table users(userId int primary key,name text,email text,dob date);

insert into users values(1,'Ram','Ram@gmail.com','2017-11-11');
insert into users values(2,'Rahim','Rahim@gmail.com','2013-11-11');
insert into users values(3,'Sumit','Sumit@gmail.com','2012-11-11');
insert into users values(4,'David','David@gmail.com','2011-11-11');

select * from users;


*/



//create a connection with mysql

var connection=mysql.createConnection({
    database:"company",
    user:"root",
    password:"admin",
    port:3306,
    host:"localhost"
});



/* GET all users  */
router.get('/users', function(req, res, next) {

    connection.query("SELECT * FROM USERS",function(error,users){
       if(error) return res.send(""+error);
       res.json(users);
    });
 
});


/* GET user by userId  */
router.get('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;

  connection.query("SELECT * FROM USERS WHERE USERID=?",[user_id],function(error,users){
    if(error) return res.send(""+error);
    res.json(users[0]);
 });

});

/* DELETE user by userId  */
router.delete('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;

  connection.query("DELETE FROM USERS WHERE USERID=?",[user_id],function(error){
    if(error) return res.send(""+error);

    connection.query("SELECT * FROM USERS",function(error,users){
        if(error) return res.send(""+error);
        res.json(users);
     });
 
  });

});


/* UPDATE user by userId  */
router.put('/users/:userId', function(req, res, next) {
  var user_id=req.params.userId;
  var user=req.body;

  connection.query("UPDATE USERS SET NAME=?,EMAIL=?,DOB=? WHERE USERID=?",
    [user.name,user.email,user.dob,user_id],function(error){
    if(error) return res.send(""+error);

    connection.query("SELECT * FROM USERS",function(error,users){
        if(error) return res.send(""+error);
        res.json(users);
     });
 
  });



});



/* ADD user */
router.post('/users', function(req, res, next) {
    var user=req.body;

    connection.query("INSERT INTO USERS SET ?",[user],function(error){
      if(error) return res.send(""+error);
  
      connection.query("SELECT * FROM USERS",function(error,users){
          if(error) return res.send(""+error);
          res.json(users);
       });
   
    });
  
});


module.exports = router;
