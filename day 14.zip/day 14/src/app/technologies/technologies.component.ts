import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies', // where to inject 
  templateUrl: './technologies.component.html', // where to display 
  styleUrls: ['./technologies.component.css'] // how to display 
})
export class TechnologiesComponent implements OnInit {

 /*  constructor() { } 

  ngOnInit(): void { 
  } */ 

  title = "Learning Technologies Top 5"; 
  
  technologies = 
  [
    {id:101, name:'Angular', likes:0, dislikes:0}, 
    {id:102, name:'NodeJS', likes:0, dislikes:0}, 
    {id:103, name:'MongoDB', likes:0, dislikes:0}, 
    {id:104, name:'Express', likes:0, dislikes:0}, 
    {id:105, name:'MySQL', likes:0, dislikes:0} 
  ]; //array 


incrementLikes(t) 
{ 
  t.likes++; 
} 

incrementDislikes(t) 
{ 
  t.dislikes++; 
} 


  constructor() {
    console.log("-- TechnologiesComponent created --");
   }

  ngOnInit(): void {
    console.log("-- TechnologiesComponent intiated --");
  }

  ngOnDestroy(): void {
    console.log("-- TechnologiesComponent destroyed --");
  }

}
