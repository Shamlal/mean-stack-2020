import { Directive, ElementRef, Renderer2, Input } from '@angular/core';

@Directive({
  selector: '[fgColor]'
})
export class FgColorDirective {

  constructor(private e: ElementRef, private r: Renderer2) {
    console.log(" FgColor Directive is created. ");
   }

   @Input()
   set fgColor(value: String){
     console.log(" Color Value in FgColor Directive : " + value); 
    this.r.setStyle(this.e.nativeElement, "color", value); 
   } 

}
