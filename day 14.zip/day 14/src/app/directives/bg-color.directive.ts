import { Directive, ElementRef, Renderer2, Input } from '@angular/core';

@Directive({
  selector: '[bgColor]'
})
export class BgColorDirective {

  constructor(private e: ElementRef, private r: Renderer2) {
    console.log(" BgColor Directive is created. ");
   }

   @Input()
   set bgColor(value: String){
     console.log(" Color Value in BgColor Directive : " + value); 
    this.r.setStyle(this.e.nativeElement, "background-color", value); 
   } 

}
