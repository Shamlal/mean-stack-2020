import { Component } from '@angular/core';

@Component({
  selector: 'app-root',  // where to inject 
  templateUrl: './app.component.html',  // where to display the data 
  styleUrls: ['./app.component.css']  // how to dispay the data 
})
export class AppComponent {
  // title = 'angular9-example001';  // what to display 
  title = 'I started a new Angular Project';  // what to display 
}
