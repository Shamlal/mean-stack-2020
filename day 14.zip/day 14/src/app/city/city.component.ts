import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit 
{ 

  message = "Hello from City. "; 
  
  @Input() 
  stateMessage = ""; 

  @Input() 
  countryMessage = ""; 

  @Output() 
  cityChanged = new EventEmitter<string>(); 


  sendMessageToState() 
  { 
    console.log("Sent message to State. " + this.message); 
    this.cityChanged.emit(this.message); 
  } 

  sendMessageToCountry() 
  { 
    console.log("Sent message to Country. " + this.message); 
    this.cityChanged.emit(this.message); 
  } 



  constructor() { }

  ngOnInit(): void {
  } 

} 
