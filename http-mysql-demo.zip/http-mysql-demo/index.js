var http=require('http');
var mysql=require("mysql");
/*
drop database company;

create database company;

use company;

create table users(userId int primary key,name text,email text,dob date);

insert into users values(1,'Ram','Ram@gmail.com','2017-11-11');
insert into users values(2,'Rahim','Rahim@gmail.com','2013-11-11');
insert into users values(3,'Sumit','Sumit@gmail.com','2012-11-11');
insert into users values(4,'David','David@gmail.com','2011-11-11');

select * from users;


*/



//create a connection with mysql

var connection=mysql.createConnection({
    database:"company",
    user:"root",
    password:"admin",
    port:3306,
    host:"localhost"
});


var server=http.createServer(function(req,res){
        connection.query("SELECT * FROM USERS",function(error,users){
           if(error) return res.send(""+error);
           res.end(JSON.stringify(users));
        });
});


server.listen(1111,function(){
   console.log("Server listen on port 1111"); 
});


